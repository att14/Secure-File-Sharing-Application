/* File worker thread handles the business of uploading, downloading, and removing files for clients with valid tokens */

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.SocketException;
import java.security.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class FileThread extends Thread {

    private final Socket socket;

    public FileThread(Socket _socket) {
        socket = _socket;
    }

    @Override
    public void run() {
        boolean proceed = true;
        try {
            System.out.println("*** New connection from " + socket.getInetAddress() + ":" + socket.getPort() + "***");
            final ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
            final ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
            Envelope response;

            do {
                Envelope e;
                byte[] initMessage = (byte[]) input.readObject();

                //unencrypted case
                if (Envelope.getEnvelopefromBytes(initMessage) != null) {
                    e = Envelope.getEnvelopefromBytes(initMessage);

                    //encrypted case;
                } else {
                    File AESfile = new File("FAESKey.bin");
                    FileInputStream fis = new FileInputStream(AESfile);
                    ObjectInputStream ois = new ObjectInputStream(fis);
                    Key AESkey = (Key) ois.readObject();

                    //recieve byte[] and decrypt
                    Cipher cipher = Cipher.getInstance("AES");
                    cipher.init(Cipher.DECRYPT_MODE, AESkey);
                    byte[] plainBytes = cipher.doFinal(initMessage);

                    //reconstruct Envelope object from decrypted byte[]
                    e = Envelope.getEnvelopefromBytes(plainBytes);
                }

                System.out.println("Request received: " + e.getMessage());

                // Handler to list files that this user is allowed to see
                if (e.getMessage().equals("LFILES")) {
                    Token t = (Token) e.getObjContents().get(0);            // gets token from e
                    String issuer = t.getIssuer();                          // gets the issuer from the token
                    String subject = t.getSubject();                        // gets the subject of the token
                    List<String> groups = t.getGroups();                    // gets the groups the token says you are a part of
                    List<ShareFile> filelist = new ArrayList<ShareFile>();  // creates a new filelist to hold the temp file names
                    List<String> finallist = new ArrayList<String>();       // will hold the filenames the user owns
                    filelist = FileServer.fileList.getFiles();              // jams every file in existence in this sucker

                    for (int i = 0; i < filelist.size(); i++) {
                        ShareFile sf = filelist.get(i);                     // sets the sharefile to a file in the list
                        if (t.getGroups().contains(sf.getGroup())) {
                            finallist.add(sf.getPath());
                        }
                    }
                    response = new Envelope("OK");                          // sets the response to OK
                    response.addObject(finallist);                          // adds the file list to the response

                    File AESfile = new File("FAESKey.bin");
                    FileInputStream fis = new FileInputStream(AESfile);
                    ObjectInputStream ois = new ObjectInputStream(fis);
                    Key AESkey = (Key) ois.readObject();

                    byte[] responseBytes = Envelope.toByteArray(response);

                    //Encrypt envelope w/ AES
                    Cipher cipher = Cipher.getInstance("AES");
                    cipher.init(Cipher.ENCRYPT_MODE, AESkey);
                    byte[] cipherBytes = cipher.doFinal(responseBytes);

                    output.writeObject(cipherBytes);
                }

                if (e.getMessage().equals("UPLOADF")) {

                    if (e.getObjContents().size() < 3) {
                        response = new Envelope("FAIL-BADCONTENTS");
                    } else {
                        if (e.getObjContents().get(0) == null) {
                            response = new Envelope("FAIL-BADPATH");
                        }
                        if (e.getObjContents().get(1) == null) {
                            response = new Envelope("FAIL-BADGROUP");
                        }
                        if (e.getObjContents().get(2) == null) {
                            response = new Envelope("FAIL-BADTOKEN");
                        } else {
                            String remotePath = (String) e.getObjContents().get(0);
                            String group = (String) e.getObjContents().get(1);
                            UserToken yourToken = (UserToken) e.getObjContents().get(2); //Extract token
                            int keyNum = (Integer)  e.getObjContents().get(3);
                            byte[] initialVector = (byte[]) e.getObjContents().get(4);
                            IvParameterSpec ivs = new IvParameterSpec(initialVector);

                            if (FileServer.fileList.checkFile(remotePath)) {
                                System.out.printf("Error: file already exists at %s\n", remotePath);
                                response = new Envelope("FAIL-FILEEXISTS"); //Success
                            } else if (!yourToken.getGroups().contains(group)) {
                                System.out.printf("Error: user missing valid token for group %s\n", group);
                                response = new Envelope("FAIL-UNAUTHORIZED");
                            } else {
                                File file = new File("shared_files/" + remotePath.replace('/', '_'));
                                file.createNewFile();
                                FileOutputStream fos = new FileOutputStream(file);
                                System.out.printf("Successfully created file %s\n", remotePath.replace('/', '_'));

                                response = new Envelope("READY"); //Success

                                File AESfile = new File("FAESKey.bin");
                                FileInputStream fis = new FileInputStream(AESfile);
                                ObjectInputStream ois = new ObjectInputStream(fis);
                                Key AESkey = (Key) ois.readObject();

                                byte[] responseBytes = Envelope.toByteArray(response);

                                //Encrypt envelope w/ AES
                                Cipher cipher = Cipher.getInstance("AES");
                                cipher.init(Cipher.ENCRYPT_MODE, AESkey);
                                byte[] cipherBytes = cipher.doFinal(responseBytes);

                                output.writeObject(cipherBytes);

                                byte[] responseCipherBytes = (byte[]) input.readObject();

                                //Decrypt response
                                cipher.init(Cipher.DECRYPT_MODE, AESkey);
                                responseBytes = cipher.doFinal(responseCipherBytes);

                                e = Envelope.getEnvelopefromBytes(responseBytes);

                                while (e.getMessage().compareTo("CHUNK") == 0) {
                                    fos.write((byte[]) e.getObjContents().get(0), 0, (Integer) e.getObjContents().get(1));
                                    response = new Envelope("READY"); //Success

                                    byte[] envBytes = Envelope.toByteArray(response);

                                    //Encrypt envelope w/ AES
                                    cipher = Cipher.getInstance("AES");
                                    cipher.init(Cipher.ENCRYPT_MODE, AESkey);
                                    cipherBytes = cipher.doFinal(envBytes);

                                    output.writeObject(cipherBytes);

                                    responseCipherBytes = (byte[]) input.readObject();

                                    //Decrypt response
                                    cipher.init(Cipher.DECRYPT_MODE, AESkey);
                                    responseBytes = cipher.doFinal(responseCipherBytes);

                                    e = Envelope.getEnvelopefromBytes(responseBytes);
                                }

                                if (e.getMessage().compareTo("EOF") == 0) {
                                    System.out.printf("Transfer successful file %s\n", remotePath);
                                    System.out.println("KeyNum = " + keyNum);
                                    FileServer.fileList.addFile(yourToken.getSubject(), group, remotePath, keyNum, initialVector);
                                    response = new Envelope("OK"); //Success
                                } else {
                                    System.out.printf("Error reading file %s from client\n", remotePath);
                                    response = new Envelope("ERROR-TRANSFER"); //Success
                                }
                                fos.close();
                            }
                        }
                    }
                    File AESfile = new File("FAESKey.bin");
                    FileInputStream fis = new FileInputStream(AESfile);
                    ObjectInputStream ois = new ObjectInputStream(fis);
                    Key AESkey = (Key) ois.readObject();

                    byte[] envBytes = Envelope.toByteArray(response);

                    //Encrypt envelope w/ AES
                    Cipher cipher = Cipher.getInstance("AES");
                    cipher.init(Cipher.ENCRYPT_MODE, AESkey);
                    byte[] cipherBytes = cipher.doFinal(envBytes);

                    output.writeObject(cipherBytes);

                } else if (e.getMessage().compareTo("DOWNLOADF") == 0) {
                    String remotePath = (String) e.getObjContents().get(0);
                    Token t = (Token) e.getObjContents().get(1);
                    ShareFile sf = FileServer.fileList.getFile("/" + remotePath);
                    if (sf == null) {
                        System.out.printf("Error: File %s doesn't exist\n", remotePath);
                        e = new Envelope("ERROR_FILEMISSING");

                    } else if (!t.getGroups().contains(sf.getGroup())) {
                        System.out.printf("Error user %s doesn't have permission\n", t.getSubject());
                        e = new Envelope("ERROR_PERMISSION");
                    } else {

                        try {
                            File f = new File("shared_files/_" + remotePath.replace('/', '_'));
                            if (!f.exists()) {
                                System.out.printf("Error file %s missing from disk\n", "_" + remotePath.replace('/', '_'));
                                e = new Envelope("ERROR_NOTONDISK");

                            } else {
                                FileInputStream fis = new FileInputStream(f);

                                do {
                                    System.out.println(fis.available());
                                    byte[] buf = new byte[4096];
                                    if (e.getMessage().compareTo("DOWNLOADF") != 0) {
                                        System.out.printf("Server error: %s\n", e.getMessage());
                                        break;
                                    }
                                    e = new Envelope("CHUNK");
                                    int n = fis.read(buf); //can throw an IOException
                                    System.out.println("N BITCHES : " + n);
                                    if (n > 0) {
                                        System.out.printf(".");
                                    } else if (n < 0) {
                                        System.out.println("Read error");

                                    }

                                    e.addObject(buf);
                                    e.addObject(new Integer(n));
                                    e.addObject(sf);

                                    File AESfile = new File("FAESKey.bin");
                                    FileInputStream AESfis = new FileInputStream(AESfile);
                                    ObjectInputStream AESois = new ObjectInputStream(AESfis);
                                    Key AESkey = (Key) AESois.readObject();

                                    byte[] envBytes = Envelope.toByteArray(e);

                                    //Encrypt envelope w/ AES
                                    Cipher cipher = Cipher.getInstance("AES");
                                    cipher.init(Cipher.ENCRYPT_MODE, AESkey);
                                    byte[] outCipherBytes = cipher.doFinal(envBytes);

                                    output.writeObject(outCipherBytes);

                                    byte[] inCipherBytes = (byte[]) input.readObject();

                                    //Decrypt response
                                    cipher.init(Cipher.DECRYPT_MODE, AESkey);
                                    byte[] responseBytes = cipher.doFinal(inCipherBytes);

                                    e = Envelope.getEnvelopefromBytes(responseBytes);

                                } while (fis.available() > 0);

                                //End download once file has been fully sent
                                if (e.getMessage().compareTo("DOWNLOADF") == 0) {
                                    e = new Envelope("EOF");

                                    File AESfile = new File("FAESKey.bin");
                                    FileInputStream AESfis = new FileInputStream(AESfile);
                                    ObjectInputStream AESois = new ObjectInputStream(AESfis);
                                    Key AESkey = (Key) AESois.readObject();

                                    byte[] envBytes = Envelope.toByteArray(e);

                                    //Encrypt envelope w/ AES
                                    Cipher cipher = Cipher.getInstance("AES");
                                    cipher.init(Cipher.ENCRYPT_MODE, AESkey);
                                    byte[] outCipherBytes = cipher.doFinal(envBytes);

                                    output.writeObject(outCipherBytes);

                                    byte[] inCipherBytes = (byte[]) input.readObject();

                                    //Decrypt response
                                    cipher.init(Cipher.DECRYPT_MODE, AESkey);
                                    byte[] responseBytes = cipher.doFinal(inCipherBytes);

                                    e = Envelope.getEnvelopefromBytes(responseBytes);

                                    if (e.getMessage().compareTo("OK") == 0) {
                                        System.out.printf("File data upload successful\n");
                                    } else {
                                        System.out.printf("Upload failed: %s\n", e.getMessage());
                                    }
                                } else {
                                    System.out.printf("Upload failed: %s\n", e.getMessage());
                                }
                                fis.close();
                            }
                        } catch (Exception e1) {
                            System.err.println("Error: " + e.getMessage());
                            e1.printStackTrace(System.err);
                        }
                    }

                    File AESfile = new File("FAESKey.bin");
                    FileInputStream AESfis = new FileInputStream(AESfile);
                    ObjectInputStream AESois = new ObjectInputStream(AESfis);
                    Key AESkey = (Key) AESois.readObject();

                    byte[] envBytes = Envelope.toByteArray(e);

                    //Encrypt envelope w/ AES
                    Cipher cipher = Cipher.getInstance("AES");
                    cipher.init(Cipher.ENCRYPT_MODE, AESkey);
                    byte[] cipherBytes = cipher.doFinal(envBytes);

                    output.writeObject(cipherBytes);

                } else if (e.getMessage().compareTo("DELETEF") == 0) {
                    String remotePath = (String) e.getObjContents().get(0);
                    Token t = (Token) e.getObjContents().get(1);
                    ShareFile sf = FileServer.fileList.getFile("/" + remotePath);

                    if (!remotePath.startsWith("/")) {
                        System.out.println("DELETEF process iniated on " + remotePath);
                    }
                    if (sf == null) {
                        System.out.printf("Error: File %s doesn't exist\n", remotePath);
                        e = new Envelope("ERROR_DOESNTEXIST");
                    } else if (!t.getGroups().contains(sf.getGroup())) {
                        System.out.printf("Error user %s doesn't have permission\n", t.getSubject());
                        e = new Envelope("ERROR_PERMISSION");
                    } else {
                        try {
                            File f = new File("shared_files/" + "_" + remotePath.replace('/', '_'));

                            if (!f.exists()) {
                                System.out.printf("Error file %s missing from disk\n", "_" + remotePath.replace('/', '_'));
                                e = new Envelope("ERROR_FILEMISSING");
                            } else if (f.delete()) {
                                System.out.printf("File %s deleted from disk\n", "_" + remotePath.replace('/', '_'));
                                FileServer.fileList.removeFile("/" + remotePath);
                                e = new Envelope("OK");
                            } else {
                                System.out.printf("Error deleting file %s from disk\n", "_" + remotePath.replace('/', '_'));
                                e = new Envelope("ERROR_DELETE");
                            }
                        } catch (Exception e1) {
                            System.err.println("Error: " + e1.getMessage());
                            e1.printStackTrace(System.err);
                            e = new Envelope(e1.getMessage());
                        }
                    }

                    File AESfile = new File("FAESKey.bin");
                    FileInputStream AESfis = new FileInputStream(AESfile);
                    ObjectInputStream AESois = new ObjectInputStream(AESfis);
                    Key AESkey = (Key) AESois.readObject();

                    byte[] envBytes = Envelope.toByteArray(e);

                    //Encrypt envelope w/ AES
                    Cipher cipher = Cipher.getInstance("AES");
                    cipher.init(Cipher.ENCRYPT_MODE, AESkey);
                    byte[] cipherBytes = cipher.doFinal(envBytes);

                    output.writeObject(cipherBytes);


                } else if (e.getMessage().equals("GETFPRINT")) {
                    PublicKey pubKey;

                    // attempt to retrieve pubKey from disk, send hash to client
                    File pubF = new File("FPubKey.bin");

                    // if file DNE, make it and genereate key pair and write to disk
                    if (!pubF.exists()) {
                        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
                        keyGen.initialize(1024);

                        KeyPair key = keyGen.genKeyPair();

                        pubKey = key.getPublic();
                        PrivateKey privKey = key.getPrivate();

                        pubF.createNewFile();
                        FileOutputStream fos = new FileOutputStream(pubF);
                        ObjectOutputStream oos = new ObjectOutputStream(fos);
                        oos.writeObject(pubKey);
                        System.out.println("FPubKey.bin created");

                        File privF = new File("FPrivkey.bin");
                        privF.createNewFile();
                        fos = new FileOutputStream(privF);
                        oos = new ObjectOutputStream(fos);
                        oos.writeObject(privKey);
                        System.out.println("FPrivkey.bin created");

                    } else {
                        FileInputStream fis = new FileInputStream(pubF);
                        ObjectInputStream ois = new ObjectInputStream(fis);

                        pubKey = (PublicKey) ois.readObject();
                    }

                    // convert pubKey to byte[] for hashing
                    ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                    ObjectOutputStream oStream = new ObjectOutputStream(bStream);
                    oStream.writeObject(pubKey);
                    byte[] keyBytes = bStream.toByteArray();

                    // hash pubKey to get fingerprint
                    MessageDigest md = MessageDigest.getInstance("SHA1");
                    md.update(keyBytes);
                    String fingerprint = new String(md.digest());

                    // construct envelope and send to client
                    e = new Envelope("OK");
                    e.addObject(pubKey);
                    e.addObject(fingerprint);

                    output.writeObject(Envelope.toByteArray(e));

                } else if (e.getMessage().equals("SKEY")) { // what does SKEY stand for?
                    byte[] cipherKeyBytes = (byte[]) e.getObjContents().get(0);

                    File privF = new File("FPrivkey.bin");
                    FileInputStream fis = new FileInputStream(privF);
                    ObjectInputStream ois = new ObjectInputStream(fis);

                    PrivateKey privKey = (PrivateKey) ois.readObject();

                    Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
                    cipher.init(Cipher.DECRYPT_MODE, privKey);
                    byte[] keyBytes = cipher.doFinal(cipherKeyBytes);

                    SecretKey AESkey = new SecretKeySpec(keyBytes, "AES");

                    response = new Envelope("OK");

                    //Encrypt w/ newly recieved AES key
                    byte[] responseBytes = Envelope.toByteArray(response);

                    //encrypt response byte[] and send
                    cipher = Cipher.getInstance("AES");
                    cipher.init(Cipher.ENCRYPT_MODE, AESkey);
                    byte[] cipherBytes = cipher.doFinal(responseBytes);
                    output.writeObject(cipherBytes);

                    File AESfile = new File("FAESKey.bin");
                    AESfile.createNewFile();
                    FileOutputStream fos = new FileOutputStream(AESfile);
                    ObjectOutputStream oos = new ObjectOutputStream(fos);
                    oos.writeObject(AESkey);


                } 
                else if (e.getMessage().equals("SENDT")) ///////////////////////////////////////////////////
                {
                    System.out.println("VERIFYING TOKEN");

                    UserToken token = (UserToken) e.getObjContents().get(0); // gets the token getToken returned

                    Boolean success = verifyToken(token);
                    
                    File AESfile = new File("FAESKey.bin");
                    FileInputStream fis = new FileInputStream(AESfile);
                    ObjectInputStream ois = new ObjectInputStream(fis);

                    Key AESkey = (Key) ois.readObject();
                    Cipher cipher = Cipher.getInstance("AES");
                    cipher.init(Cipher.ENCRYPT_MODE, AESkey);
                  
                    e = new Envelope("OK");
                    e.addObject(success);

                    byte[] cipherBytes = cipher.doFinal(Envelope.toByteArray(e));

                    output.writeObject(cipherBytes);
              
                } else if (e.getMessage().equals("DISCONNECT")) {
                    socket.close();
                    proceed = false;
                }
            } while (proceed);
        } catch (SocketException e) {
            System.out.println("Socket reset");
        } catch (EOFException eof) {
            //DO NOTHING
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }
    
    public boolean verifyToken(UserToken token) {
        FileInputStream fis = null;
        ObjectInputStream ois = null;
        try {
            String tokenContents = token.getIssuer() + ";" + token.getSubject();
            for (String group : token.getGroups()) {
                tokenContents = tokenContents + ";" + group;
            }
            tokenContents = tokenContents + ";" + token.getFileServerName();

            byte[] tokenBytes = tokenContents.getBytes();

            File pubF = new File("GPubKey.bin");
            fis = new FileInputStream(pubF);
            ois = new ObjectInputStream(fis);
            PublicKey pubKey = (PublicKey) ois.readObject();

            Signature sig = Signature.getInstance("SHA1withRSA");
            sig.initVerify(pubKey);
            sig.update(tokenBytes);
            return sig.verify(token.getSignature());

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FileThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FileThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SignatureException ex) {
            ex.printStackTrace(System.err);
            return false;
        } catch (InvalidKeyException ex) {
            ex.printStackTrace(System.err);
            return false;
        } catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace(System.err);
            return false;
        } finally {
            try {
                fis.close();
            } catch (IOException ex) {
                Logger.getLogger(FileThread.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                ois.close();
            } catch (IOException ex) {
                Logger.getLogger(FileThread.class.getName()).log(Level.SEVERE, null, ex);
            }
            return true;
        }
    }      
}
